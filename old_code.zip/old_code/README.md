## Reflexive

A package to conduct Reflexive Expression analysis using AWS.