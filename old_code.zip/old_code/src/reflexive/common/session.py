import os
import logging,coloredlogs
import boto3

from reflexive.common.parameters import Parameters

coloredlogs.install(level='INFO')

class Session:
    
    logger = logging.getLogger(__name__)

    def __init__(self,profile="default"):
        self.profile = profile
        self.parameters = Parameters(profile)
        try:
            self.aws_session = boto3.Session(profile_name=profile)
            self.region = self.aws_session.region_name
            self.logger.info("AWS region:",self.region)
            self.access_key = self.aws_session.get_credentials().access_key
            self.logger.debug("AWS access key:",self.access_key)
            self.account_number = self.aws_session.client('sts').get_caller_identity().get('Account')
        except Exception as err:
            self.logger.error("Unable to retrieve AWS credentials",err)
            self.access_key = None
            self.region = None
            self.account_number = None
        
    def set_parameters(self,name_prefix="rfx",local_path=None,date_string=None):
        self.parameters.set_parameters(name_prefix,local_path,date_string)